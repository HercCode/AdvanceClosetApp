import numpy
num = 5
for i in range(num):
    row = []
    print()
    for i in range(num):
        print(j * num + i)
